require = require("esm")(module, { mode: "auto", cjs: true });

module.exports = require("./src/module.js");

require = require("@std/esm")(module, { esm: "js", cjs: true });

module.exports = require("./runProject.js");

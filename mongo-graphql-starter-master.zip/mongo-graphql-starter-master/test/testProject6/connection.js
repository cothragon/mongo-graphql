export default "mongodb://localhost:27017/mongo-graphql-starter";

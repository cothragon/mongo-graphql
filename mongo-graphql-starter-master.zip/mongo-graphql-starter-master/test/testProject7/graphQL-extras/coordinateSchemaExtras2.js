export default {
  Query: `
    getCoordinate(_id: String): [Coordinate]
    randomQuery: Coordinate
    `
};
